<?php

class Item extends AppModel 
{

}

?>
